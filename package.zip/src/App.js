//* Bootstrap CSS ve JS.
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.min.js";
import Candidate from "./components/Candidate";
import { Provider } from "react-redux";

function App() {
  return (
    <Provider>

      <Candidate />
    </Provider>
  
  );
}

export default App;

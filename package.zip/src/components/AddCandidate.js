import { useRef } from "react";

function AddCandidate({ setList }) {
  const adRef = useRef();
  const soyadRef = useRef();

  function handleSubmit(event) {
    debugger;
    event.preventDefault(); //? Submit işleminden sonra sayfanın yenilenmesini önlemek için kullanıldı.

    const ad = event.target.elements.ad.value;
    const soyad = event.target.elements.soyad.value;
    const newList = {
      id: 3,
      ad,
      soyad,
    };

    setList((prevList) => {
      return prevList.concat(newList);
    });

    adRef.current.value = "";
    soyadRef.current.value = "";
  }

  return (
    <>
      <form onSubmit={handleSubmit}>
        <div className="form-row">
          <div className="form-group col-md-6">
            <input
              className="form-control"
              type="text"
              name="ad"
              placeholder="Ad giriniz."
              ref={adRef}
              onInvalid="alert('You must fill out the form!');"
              required
            />
          </div>
          <div className="form-group col-md-6">
            <input
              className="form-control"
              type="text"
              name="soyad"
              placeholder="Soyad giriniz."
              ref={soyadRef}
              onInvalid="alert('You must fill out the form!');"
              required
            />
          </div>
        </div>
        <div className="form-row">
          <div className="form-group col-md-6">
            <input
              className="form-control"
              type="text"
              name="ad"
              placeholder="Ad giriniz."
              ref={adRef}
              onInvalid="alert('You must fill out the form!');"
              required
            />
          </div>
          <div className="form-group col-md-6">
            <input
              className="form-control"
              type="text"
              name="soyad"
              placeholder="Soyad giriniz."
              ref={soyadRef}
              onInvalid="alert('You must fill out the form!');"
              required
            />
          </div>
        </div>

        <div className="modal-footer">
          <button
            type="button"
            className="btn btn-secondary"
            data-bs-dismiss="modal"
          >
            Close
          </button>
          <button type="submit" className="btn btn-primary">
            Save changes
          </button>
        </div>
      </form>
    </>
  );
}

export default AddCandidate;

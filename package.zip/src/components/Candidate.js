import { useEffect, useState } from "react";
import AddCandidate from "./AddCandidate";
import EditCandidate from "./EditCandidate";
import { useDispatch } from "react-redux";
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
function Candidate() {



const initialStateCandidate = {
    candidates: [],
};
  //? Custom bir list tanımlandı, normalde backend tarafından liste gelecek.
  const dispatch = useDispatch();
  const [candidates, setCandidates] = useState([]);

  const [data, setData] = useState({
    name: "",
    surname: "",
    mail: "",
    phone: "",
    status: "",
  });
  const fetchCandidates =
    ("candidate/fetchCandidates",
    async (payload) => {
      try {
        const result = await fetch(
          "http://localhost:8081/api/v1/candidate/findall",
          {
            method: "GET",
          }
        )
          .then((p) => p.json())
          .catch((err) => console.log(err));
        return result;
      } catch (error) {}
    });
  const getCandidates = () => {
    dispatch(fetchCandidates()).then((data) => setCandidates(data.payload));
  };

  useEffect(() => {
    getCandidates();
  }, []);

  const list = [
    {
      id: 1,
      ad: "Mehmet",
      soyad: "Çifçi",
    },
    {
      id: 2,
      ad: "Mehmet",
      soyad: "Gürsoy",
    },
  ];

  const [lists, setList] = useState(list);
  const [updateState, setUpdateState] = useState(-1); //* Default değeri -1.

  return (
    <div className="container">
      <div className="jumbotron">
        <div className="card">
          <div className="card-header">Candidate Case</div>
          <div className="card-body">
            <button
              type="button"
              className="btn btn-primary"
              data-bs-toggle="modal"
              data-bs-target="#exampleModal"
            >
              Yeni Aday
            </button>
            <div
              className="modal fade"
              id="exampleModal"
              tabIndex="-1"
              aria-labelledby="exampleModalLabel"
              aria-hidden="true"
            >
              <div className="modal-dialog modal-lg">
                <div className="modal-content">
                  <div className="modal-header">Aday Ekle</div>
                  <div className="modal-body">
                    <AddCandidate setList={setList} />
                  </div>
                </div>
              </div>
            </div>

            <form onSubmit={handleUpdate}>
              <table className="table table-bordered">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Ad</th>
                    <th scope="col">Soyad</th>
                    <th scope="col">Mail</th>
                    <th scope="col">Telefon</th>
                    <th scope="col">Durum</th>
                    <th scope="col">İşlemler</th>
                  </tr>
                </thead>
                <tbody>
                  {candidates &&
                    candidates.map((candidate) =>
                      /* Eğer bir updateState varsa (güncelleme buttonuna basıldığında candidate id gönderilir ve yeni değer alıp -1'den farklı bir değer olur); 
                       bu durumda güncelleme işlemidir. 
                    */
                      updateState === candidate.id ? (
                        <EditCandidate
                          candidate={candidate}
                          lists={lists}
                          setList={setList}
                        />
                      ) : (
                        <tr key={candidate.id}>
                          <th scope="row">{candidate.id}</th>
                          <td className="col-md-2">{candidate.name}</td>
                          <td className="col-md-2">{candidate.surname}</td>
                          <td className="col-md-2">{candidate.mail}</td>
                          <td className="col-md-2">{candidate.phone}</td>
                          <td>
                            <select
                              className="select form-control"
                              id="title"
                              onChange={(e) => handleEdit(e)}
                              value={data.status}
                              onInvalid="alert('You must fill out the form!');"
                              required
                            ></select>
                          </td>

                          <td>
                            <button
                              className="btn btn-primary"
                              type="button"
                              onClick={() => handleEdit(candidate.id)}
                            >
                              <i className="far fa-eye"></i>
                            </button>

                            <button
                              className="btn btn-success  "
                              type="button"
                              onClick={() => handleEdit(candidate.id)}
                            >
                              <i className="fas fa-edit"></i>
                            </button>
                            <button
                              className="btn btn-danger"
                              type="button"
                              onClick={() => handleDelete(candidate.id)}
                            >
                              <i className="far fa-trash-alt"></i>
                            </button>
                          </td>
                        </tr>
                      )
                    )}
                </tbody>
              </table>
            </form>
          </div>
        </div>
      </div>
    </div>
  );

  //? Kullanıcı bilgilerini güncelleyen metot.
  function handleUpdate(e) {
    e.preventDefault();
    setUpdateState(-1);
  }

  //? Kullanıcı güncellemek için "Güncelle" buttonuna ilk basıldığında kullanılan metot; parametre olarak candidate id alır.
  function handleEdit(id) {
    //* id setUpdateState'e gönderilir.
    setUpdateState(id);
  }

  //? Kullanıcı silmek için kullanılan metot; parametre olarak candidate id alır.
  function handleDelete(id) {
    const newList = lists.filter((candidate) => candidate.id !== id);
    setList(newList);
  }
}

export default Candidate;

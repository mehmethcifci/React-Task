function EditCandidate({ candidate, lists, setList }) {
  function handleInput(e) {
    const newList = lists.map((li) =>
      li.id === candidate.id ? { ...li, [e.target.name]: e.target.value } : li
    );
    setList(newList);
  }

  return (
    <tr>
      <th scope="row">{candidate.id}</th>
      <td>
        <input
          type="text"
          name="ad"
          value={candidate.name}
          onChange={handleInput}
          onInvalid="alert('You must fill out the form!');"
          required
        />
      </td>
      <td>
        <input
          type="text"
          name="soyad"
          value={candidate.surname}
          onChange={handleInput}
          onInvalid="alert('You must fill out the form!');"
          required
        />
      </td>
      <td>
        <input
          type="mail"
          name="mail"
          value={candidate.mail}
          onChange={handleInput}
          onInvalid="alert('You must fill out the form!');"
          required
        />
      </td>
      <td>
        <input
          type="text"
          name="phone"
          value={candidate.phone}
          onChange={handleInput}
          onInvalid="alert('You must fill out the form!');"
          required
        />
      </td>
      <td>
        <select
          className="select form-control"
          id="title"
          onChange={(e) => handleInput(e)}
          value={candidate.status}
          onInvalid="alert('You must fill out the form!');"
          required
        >
          <option value="-1">Choose one</option>
          <option value="SOURCED">Sourced</option>
          <option value="INTERVIEWING">Interviewing</option>
          <option value="OFFER_SENT">Offer Sent</option>
          <option value="HIRED">Hired</option>
        </select>
        
      </td>
      <td>
        <button type="submit" className="btn btn-success">
          Güncelle
        </button>
      </td>
    </tr>
  );
}

export default EditCandidate;
